# WMCT Core

This variant is for the Official WMCT Minecraft Event on Minecraft Bedrock Edition. Many features **will not work** if compiled and used on servers. Please use the official release!