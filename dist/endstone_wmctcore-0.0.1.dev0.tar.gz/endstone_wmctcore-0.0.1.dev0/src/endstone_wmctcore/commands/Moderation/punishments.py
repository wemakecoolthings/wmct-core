import re
from datetime import datetime
import pytz
import time
from endstone import ColorFormat, Player
from endstone.command import CommandSender
from endstone_wmctcore.utils.commandUtil import create_command

from typing import TYPE_CHECKING, Optional

from endstone_wmctcore.utils.dbUtil import UserDB
from endstone_wmctcore.utils.formWrapperUtil import ActionFormResponse, ActionFormData
from endstone_wmctcore.utils.prefixUtil import modLog, errorLog

if TYPE_CHECKING:
    from endstone_wmctcore.wmctcore import WMCTPlugin

# Register command
command, permission = create_command(
    "punishments",
    "Manage punishment history of a specified player!",
    ["/punishments <player: player> [page: int]", "/punishments (remove)<punishment_removal: remove_punishment_log>"],
    ["wmctcore.command.punishments"]
)

def handler(self: "WMCTPlugin", sender: CommandSender, args: list[str]) -> bool:
    """Command to fetch or remove a player's punishment history."""

    if not args:
        sender.send_message(ColorFormat.red("Usage: /punishments <player> [page] OR /punishments remove <player>"))
        return False

    action = args[0].lower()

    if action == "remove":
        return handle_punishment_removal(self, sender, args[1:])

    target_name = args[0]
    page = int(args[1]) if len(args) > 1 and args[1].isdigit() else 1

    if page < 1:
        sender.send_message(f"{errorLog()}Page number must be 1 or higher")
        return False

    # Retrieve punishment history
    db = UserDB("wmctcore_users.db")
    history = db.get_punishment_history(target_name)

    if not history:
        sender.send_message(f"{modLog()}No punishment history found for {ColorFormat.YELLOW}{target_name}")
        return True

    # Paginate (5 per page)
    per_page = 5
    total_pages = (len(history) + per_page - 1) // per_page
    start = (page - 1) * per_page
    end = start + per_page
    paginated_history = history[start:end]

    # Build response
    msg = [f"{modLog()}Punishment History for {ColorFormat.YELLOW}{target_name} {ColorFormat.GRAY}(Page {page}/{total_pages}){ColorFormat.GOLD}:§r"]
    for entry in paginated_history:
        msg.append(f"§7- {entry}")

    # Show navigation hint
    if page < total_pages:
        msg.append(f"§8Use §e/punishments {target_name} {page + 1} §8for more.")

    sender.send_message(f"\n".join(msg))
    return True

def handle_punishment_removal(self: "WMCTPlugin", sender: CommandSender, args: list[str]) -> bool:
    """Handles the removal of punishment logs via an interactive menu."""
    if not isinstance(sender, Player):
        sender.send_error_message("This command can only be executed by a player.")
        return False

    online_players = [player.name for player in self.server.online_players]

    if not online_players:
        sender.send_message(f"{errorLog()}No online players available to manage.")
        return True

    # Create an ActionFormData menu for selecting a player
    form = ActionFormData()
    form.title("Select a Player")
    form.body("Choose to manage punishment logs:")

    for player_name in online_players:
        form.button(player_name)

    # Define the submit callback for selecting a player
    def select_player(sender: Player, result: ActionFormResponse):
        if not result.canceled:
            try:
                selected_index = int(result.selection)
                if 0 <= selected_index < len(online_players):
                    target_name = online_players[selected_index]
                    target = self.server.get_player(target_name)  # Fetch the target player object
                    open_punishment_log_menu(sender, target)  # Pass both sender and target
                else:
                    sender.send_message(f"{errorLog()}Invalid selection.")
            except ValueError:
                sender.send_message(f"{errorLog()}Invalid selection index.")

    # Show the player selection menu to the sender
    form.show(sender).then(
        lambda result=ActionFormResponse: select_player(sender, result)
    )
    return True


def open_punishment_log_menu(sender: Player, target: Player):
    """Opens a submenu displaying the punishment logs of the selected player."""
    db = UserDB("wmctcore_users.db")
    target_name = target.name
    history = db.get_punishment_history(target_name)  # Ensure this returns the correct format

    if not history:
        sender.send_message(f"{modLog()}No punishment history found for {ColorFormat.YELLOW}{target_name}")
        return

    # Debugging: Ensure history contains data
    print(f"DEBUG: Retrieved punishment history for {target_name}: {history}")

    form = ActionFormData()
    form.title(f"Punishment Log for {target_name}")
    form.body("Select a punishment entry to remove:")

    indexed_entries = []

    for i, entry in enumerate(history):
        entry_text = f"{i + 1} - {entry}"  # Display the entry with a numbered index
        indexed_entries.append((entry_text, i))  # Store the displayed text and its index

    if not indexed_entries:
        sender.send_message(f"{modLog()}No valid punishment entries found for {ColorFormat.YELLOW}{target_name}")
        return

    # Add punishment entries as buttons
    for entry_text, _ in indexed_entries:
        form.button(entry_text)

    cancel_index = len(indexed_entries)  # Correctly track cancel button index
    form.button("Cancel")  # Add cancel button

    def select_punishment(sender: Player, result: ActionFormResponse, target: Player):
        """Handles the sender's selection from the punishment log menu."""
        if result.canceled or result.selection == cancel_index:
            sender.send_message(f"{modLog()}Punishment log selection canceled.")
            return

        try:
            selected_index = int(result.selection)
            if 0 <= selected_index < len(indexed_entries):
                _, selected_log_id = indexed_entries[selected_index]

                # Debugging: Confirm selected log ID
                print(f"DEBUG: Selected Log ID {selected_log_id} for removal.")

                # Create confirmation form
                confirm_form = ActionFormData()
                confirm_form.title("Confirm Removal")
                confirm_form.body(
                    f"Are you sure you want to remove this punishment log entry?\n\n"
                    f"{ColorFormat.GOLD}Player: {ColorFormat.YELLOW}{target.name}\n"
                    f"{ColorFormat.GOLD}Log ID: {ColorFormat.YELLOW}{selected_log_id}"
                )
                confirm_form.button(f"{ColorFormat.GREEN}Yes, Remove")
                confirm_form.button(f"{ColorFormat.RED}No, Cancel")

                def confirm_removal(sender: Player, confirm_result: ActionFormResponse, target: Player, selected_log_id: int):
                    """Handles confirmation of removal."""
                    if confirm_result.selection == 0:  # 'Yes' button clicked
                        db.remove_punishment_entry_by_id(selected_log_id)  # Use ID directly
                        sender.send_message(
                            f"{modLog()}Removed punishment entry for {ColorFormat.YELLOW}{target.name} - Log ID: {selected_log_id}"
                        )
                    else:
                        sender.send_message(f"{modLog()}Punishment log removal canceled.")

                # Show the confirmation form and wait for response
                confirm_form.show(sender).then(lambda confirm_result: confirm_removal(sender, confirm_result, target, selected_log_id))

            else:
                print(f"DEBUG: Invalid selection index {selected_index}, valid range is 0-{len(indexed_entries)-1}")
                sender.send_message(f"{errorLog()}Invalid selection. Please try again.")

        except ValueError:
            print(f"DEBUG: ValueError when parsing selection {result.selection}")
            sender.send_message(f"{errorLog()}Invalid selection index.")

    # Show the punishment log selection form to the sender
    form.show(sender).then(lambda result: select_punishment(sender, result, target))
