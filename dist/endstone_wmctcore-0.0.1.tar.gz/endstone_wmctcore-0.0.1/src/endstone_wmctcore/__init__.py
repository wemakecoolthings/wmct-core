from src.endstone_wmctcore.wmctcore import WMCTPlugin

__all__ = ["WMCTPlugin"]